const express = require("express");
const dotenv = require("dotenv");
require("dotenv").config();
const authRoutes = require("./routes/Auth/auth");
const userRoutes = require("./routes/User/users");
const customer = require("./routes/Customer/customer");
const role = require("./routes/Role/role");
const positionsRoutes = require("./routes/Positions/positions");
const StaffManager = require("./routes/StaffManager/staffManager");
const categoryRoutes = require('./routes/categoryRoutes/categoryRoutes');
const documentRoutes = require('./routes/dataroomRoutes/Document'); 
const folderRoutes = require('./routes/Folder/folderRoutes');
const cors = require("cors");

const app = express();
app.use(cors()); 
app.use(express.json());

// auth routes
app.use("/api/auth", authRoutes);
// customer routes
app.use("/api/customer", customer);
// user routes
app.use("/api/users", userRoutes);
// role routes
app.use("/api/role", role);
// positions routes
app.use("/api/positions", positionsRoutes);
// staff manager routes
app.use("/api/staffmanager", StaffManager);

app.use('/api/categories', categoryRoutes);
app.use('/api/documents', documentRoutes);
app.use('/api/folders', folderRoutes);
// Create upload directories
const fs = require('fs');
const uploadDir = process.env.UPLOAD_DIR || './uploads';
const tempDir = process.env.TEMP_DIR || './temp';

if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
}
if (!fs.existsSync(tempDir)) {
    fs.mkdirSync(tempDir, { recursive: true });
}

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server chạy trên http://localhost:${PORT}`));

const express = require("express");
const router = express.Router();
const DocumentController = require("../../controllers/document/DocumentController");
const { authenticate, authorize } = require("../../middlewares/authMiddleware");

// Public routes
router.get("/", DocumentController.getAllDocuments);
router.get("/recent", DocumentController.getRecentDocuments);
router.get("/statistics", DocumentController.getDocumentStatistics);

// Protected routes (require authentication)
router.use(authenticate);

// Document CRUD operations
router.post("/", authorize('ADMIN', 'STAFF'), DocumentController.createDocument);
router.get("/search", DocumentController.searchDocuments);
router.get("/folder/:folderId", DocumentController.getDocumentsByFolder);
router.get("/user/:userId", authorize(['ADMIN']), DocumentController.getDocumentsByUser);

// Document specific operations
router.get("/:id", DocumentController.getDocumentById);
router.put("/:id", authorize('ADMIN', 'STAFF'), DocumentController.updateDocument);
router.delete("/:id", authorize('ADMIN'), DocumentController.deleteDocument);
router.put("/:id/status", authorize('ADMIN'), DocumentController.toggleDocumentStatus);

// Document access operations
router.get("/:id/download", DocumentController.downloadDocument);
router.get("/:id/view", DocumentController.viewDocument);
router.get("/:id/preview-file", DocumentController.previewDocumentFile);

module.exports = router;
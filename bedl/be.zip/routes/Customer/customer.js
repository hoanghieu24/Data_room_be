const express = require("express");
const router = express.Router();
const authController = require("../../controllers/Auth/authController");
const CustomerController = require("../../controllers/Customer/customerController");

router.post(
  "/",
  authController.authMiddleware(["ADMIN"]),
  CustomerController.addCustomer
);

router.delete(
  "/:id",
  authController.authMiddleware(["ADMIN"]),
  CustomerController.deleteCustomer
);

router.get(
  "/",
  authController.authMiddleware(["ADMIN"]),
  CustomerController.getAllCustomer
);

router.delete(
  "/",
  authController.authMiddleware(["ADMIN"]),
  CustomerController.deleteCustomer
);

router.put(
  "/change-status/:id",
  authController.authMiddleware(["ADMIN"]),
  CustomerController.changeStatus
);

router.put(
  "/change-is-vip/:id",
  authController.authMiddleware(["ADMIN"]),
  CustomerController.changeIsVip
);

router.put("/:id",
  authController.authMiddleware(["ADMIN"]),
  CustomerController.updateCustomer
);

module.exports = router;

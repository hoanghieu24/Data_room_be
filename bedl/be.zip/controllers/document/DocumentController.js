const DocumentModel = require("../../models/DocumentModel/DocumentModel");
const { generateDocumentCode } = require("../../utils/documentUtils");
const path = require("path");
const fs = require("fs").promises;
const multer = require("multer");
const { v4: uuidv4 } = require("uuid");

// Configure multer for file upload
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadPath = process.env.UPLOAD_PATH || "./uploads/documents";
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        const uniqueName = `${uuidv4()}${path.extname(file.originalname)}`;
        cb(null, uniqueName);
    }
});

const fileFilter = (req, file, cb) => {
    const allowedTypes = [
        'application/pdf',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/msword',
        'text/plain',
        'image/jpeg',
        'image/png',
        'image/gif'
    ];
    
    if (allowedTypes.includes(file.mimetype)) {
        cb(null, true);
    } else {
        cb(new Error("File type not allowed"), false);
    }
};

const upload = multer({
    storage: storage,
    fileFilter: fileFilter,
    limits: {
        fileSize: 50 * 1024 * 1024 // 50MB limit
    }
}).single("file");

class DocumentController {
    // Get all documents
    static async getAllDocuments(req, res) {
        try {
            const documents = await DocumentModel.findAll();
            res.json({
                success: true,
                message: "Documents retrieved successfully",
                documents: documents,
                count: documents.length
            });
        } catch (error) {
            console.error("Error getting documents:", error);
            res.status(500).json({
                success: false,
                message: "Error retrieving documents",
                error: error.message
            });
        }
    }

    // Get document by ID
    static async getDocumentById(req, res) {
        try {
            const { id } = req.params;
            const document = await DocumentModel.findById(id);
            
            if (!document) {
                return res.status(404).json({
                    success: false,
                    message: "Document not found"
                });
            }
            
            res.json({
                success: true,
                message: "Document retrieved successfully",
                document: document
            });
        } catch (error) {
            console.error("Error getting document:", error);
            res.status(500).json({
                success: false,
                message: "Error retrieving document",
                error: error.message
            });
        }
    }

    static async createDocument(req, res) {
    try {
        console.log("🔥 [CREATE DOCUMENT] API HIT");

        upload(req, res, async (err) => {
            if (err) {
                console.error("❌ Multer error:", err);
                return res.status(400).json({
                    success: false,
                    message: "File upload error",
                    error: err.message
                });
            }

            try {
                // ===== DEBUG AUTH =====
                console.log("👤 req.user:", req.user);
                console.log("🔑 role_code:", req.user?.role_code);

                // ===== DEBUG BODY =====
                console.log("📦 req.body:", req.body);

                // ===== DEBUG FILE =====
                console.log("📁 req.file:", req.file);

                const {
                    name,
                    description,
                    folder_id,
                    access_level = "restricted",
                    allowed_roles = ["ADMIN"],
                    allowed_users,
                    metadata,
                    tags,
                    is_encrypted = false,
                    expiry_date
                } = req.body;

                // Validate required fields
                if (!name || !req.file) {
                    console.warn("⚠️ Missing name or file");
                    return res.status(400).json({
                        success: false,
                        message: "Name and file are required"
                    });
                }

                // Generate document code
                const document_code = await generateDocumentCode();
                console.log("🆔 document_code:", document_code);

                // ===== PARSE DEBUG =====
                let parsedAllowedRoles = ["ADMIN"];
                if (allowed_roles) {
                    try {
                        parsedAllowedRoles = Array.isArray(allowed_roles)
                            ? allowed_roles
                            : JSON.parse(allowed_roles);
                    } catch (e) {
                        console.warn("⚠️ allowed_roles parse fail:", allowed_roles);
                    }
                }

                console.log("🛂 parsedAllowedRoles:", parsedAllowedRoles);

                let parsedAllowedUsers = null;
                if (allowed_users) {
                    try {
                        parsedAllowedUsers = Array.isArray(allowed_users)
                            ? allowed_users
                            : JSON.parse(allowed_users);
                    } catch (e) {
                        console.warn("⚠️ allowed_users parse fail");
                    }
                }

                let parsedMetadata = null;
                if (metadata) {
                    try {
                        parsedMetadata = JSON.parse(metadata);
                    } catch (e) {
                        console.warn("⚠️ metadata parse fail");
                    }
                }

                let parsedTags = null;
                if (tags) {
                    try {
                        parsedTags = Array.isArray(tags) ? tags : JSON.parse(tags);
                    } catch (e) {
                        console.warn("⚠️ tags parse fail");
                    }
                }

                // ===== FILE INFO =====
                const file_name = req.file.originalname;
                const file_path = req.file.path;
                const file_size = req.file.size;
                const file_type = path.extname(file_name).substring(1).toLowerCase();
                const mime_type = req.file.mimetype;

                console.log("📄 File info:", {
                    file_name,
                    file_path,
                    file_size,
                    file_type,
                    mime_type
                });

                // Uploaded user
                const uploaded_by = req.user?.id || 1;
                console.log("⬆️ uploaded_by:", uploaded_by);

                const documentData = {
                    document_code,
                    folder_id: folder_id || null,
                    name,
                    description: description || null,
                    file_name,
                    file_path,
                    file_size,
                    file_type,
                    mime_type,
                    version: 1,
                    access_level,
                    allowed_roles: parsedAllowedRoles,
                    allowed_users: parsedAllowedUsers,
                    metadata: parsedMetadata,
                    tags: parsedTags,
                    is_encrypted: is_encrypted ? 1 : 0,
                    expiry_date: expiry_date || null,
                    uploaded_by
                };

                console.log("📑 documentData:", documentData);

                const newDocument = await DocumentModel.create(documentData);

                console.log("✅ Document created:", newDocument.id);

                res.status(201).json({
                    success: true,
                    message: "Document created successfully",
                    document: newDocument
                });

            } catch (error) {
                if (req.file) {
                    await fs.unlink(req.file.path).catch(console.error);
                }

                console.error("🔥 CREATE DOCUMENT ERROR:", error);
                res.status(500).json({
                    success: false,
                    message: "Error creating document",
                    error: error.message
                });
            }
        });
    } catch (error) {
        console.error("💥 OUTER ERROR:", error);
        res.status(500).json({
            success: false,
            message: "Error creating document",
            error: error.message
        });
    }
}

    // Update document
    static async updateDocument(req, res) {
        try {
            const { id } = req.params;
            const updateData = req.body;

            // Check if document exists
            const existingDocument = await DocumentModel.findById(id);
            if (!existingDocument) {
                return res.status(404).json({
                    success: false,
                    message: "Document not found"
                });
            }

            // Parse JSON fields if provided
            if (updateData.allowed_roles) {
                try {
                    updateData.allowed_roles = Array.isArray(updateData.allowed_roles)
                        ? updateData.allowed_roles
                        : JSON.parse(updateData.allowed_roles);
                } catch (e) {
                    return res.status(400).json({
                        success: false,
                        message: "Invalid allowed_roles format"
                    });
                }
            }

            if (updateData.allowed_users) {
                try {
                    updateData.allowed_users = Array.isArray(updateData.allowed_users)
                        ? updateData.allowed_users
                        : JSON.parse(updateData.allowed_users);
                } catch (e) {
                    return res.status(400).json({
                        success: false,
                        message: "Invalid allowed_users format"
                    });
                }
            }

            if (updateData.metadata) {
                try {
                    updateData.metadata = JSON.parse(updateData.metadata);
                } catch (e) {
                    return res.status(400).json({
                        success: false,
                        message: "Invalid metadata format"
                    });
                }
            }

            if (updateData.tags) {
                try {
                    updateData.tags = Array.isArray(updateData.tags)
                        ? updateData.tags
                        : JSON.parse(updateData.tags);
                } catch (e) {
                    return res.status(400).json({
                        success: false,
                        message: "Invalid tags format"
                    });
                }
            }

            // Update document
            const updatedDocument = await DocumentModel.update(id, updateData);

            res.json({
                success: true,
                message: "Document updated successfully",
                document: updatedDocument
            });
        } catch (error) {
            console.error("Error updating document:", error);
            res.status(500).json({
                success: false,
                message: "Error updating document",
                error: error.message
            });
        }
    }

    // Delete document (soft delete)
    static async deleteDocument(req, res) {
        try {
            const { id } = req.params;

            // Check if document exists
            const existingDocument = await DocumentModel.findById(id);
            if (!existingDocument) {
                return res.status(404).json({
                    success: false,
                    message: "Document not found"
                });
            }

            // Soft delete document
            const deleted = await DocumentModel.delete(id);

            if (deleted) {
                res.json({
                    success: true,
                    message: "Document deleted successfully"
                });
            } else {
                res.status(500).json({
                    success: false,
                    message: "Failed to delete document"
                });
            }
        } catch (error) {
            console.error("Error deleting document:", error);
            res.status(500).json({
                success: false,
                message: "Error deleting document",
                error: error.message
            });
        }
    }

    // Download document
    static async downloadDocument(req, res) {
        try {
            const { id } = req.params;

            // Get document
            const document = await DocumentModel.findById(id);
            if (!document) {
                return res.status(404).json({
                    success: false,
                    message: "Document not found"
                });
            }

            // Check access permission
            const hasAccess = await DocumentController.checkDocumentAccess(req.user, document);
            if (!hasAccess) {
                return res.status(403).json({
                    success: false,
                    message: "Access denied"
                });
            }

            // Check if file exists
            try {
                await fs.access(document.file_path);
            } catch (error) {
                return res.status(404).json({
                    success: false,
                    message: "File not found on server"
                });
            }

            // Increment download count
            await DocumentModel.incrementDownloadCount(id);

            // Set headers for download
            res.setHeader('Content-Type', document.mime_type || 'application/octet-stream');
            res.setHeader('Content-Disposition', `attachment; filename="${document.file_name}"`);
            res.setHeader('Content-Length', document.file_size);

            // Send file
            res.download(document.file_path, document.file_name);
        } catch (error) {
            console.error("Error downloading document:", error);
            res.status(500).json({
                success: false,
                message: "Error downloading document",
                error: error.message
            });
        }
    }

    // View document (preview)
    static async viewDocument(req, res) {
        try {
            const { id } = req.params;

            // Get document
            const document = await DocumentModel.findById(id);
            if (!document) {
                return res.status(404).json({
                    success: false,
                    message: "Document not found"
                });
            }

            // Check access permission
            const hasAccess = await this.checkDocumentAccess(req.user, document);
            if (!hasAccess) {
                return res.status(403).json({
                    success: false,
                    message: "Access denied"
                });
            }

            // Increment view count
            await DocumentModel.incrementViewCount(id);

            // Return document info for preview
            res.json({
                success: true,
                message: "Document ready for preview",
                document: {
                    id: document.id,
                    name: document.name,
                    file_name: document.file_name,
                    file_type: document.file_type,
                    mime_type: document.mime_type,
                    file_size: document.file_size,
                    preview_url: `/api/documents/${id}/preview-file`
                }
            });
        } catch (error) {
            console.error("Error viewing document:", error);
            res.status(500).json({
                success: false,
                message: "Error viewing document",
                error: error.message
            });
        }
    }

    // Serve preview file
    static async previewDocumentFile(req, res) {
        try {
            const { id } = req.params;

            // Get document
            const document = await DocumentModel.findById(id);
            if (!document) {
                return res.status(404).send("Document not found");
            }

            // Check access permission
            const hasAccess = await this.checkDocumentAccess(req.user, document);
            if (!hasAccess) {
                return res.status(403).send("Access denied");
            }

            // Check if file exists
            try {
                await fs.access(document.file_path);
            } catch (error) {
                return res.status(404).send("File not found");
            }

            // Set headers for inline viewing
            res.setHeader('Content-Type', document.mime_type);
            res.setHeader('Content-Disposition', `inline; filename="${document.file_name}"`);

            // Send file
            res.sendFile(path.resolve(document.file_path));
        } catch (error) {
            console.error("Error previewing document:", error);
            res.status(500).send("Error previewing document");
        }
    }

    // Search documents
    static async searchDocuments(req, res) {
        try {
            const {
                searchTerm,
                fileType,
                accessLevel,
                folderId,
                isActive = 1,
                page = 1,
                limit = 20
            } = req.query;

            const searchParams = {
                searchTerm,
                fileType,
                accessLevel,
                folderId,
                isActive: isActive === 'false' ? 0 : 1
            };

            // Get documents with pagination
            const documents = await DocumentModel.search(searchParams);
            
            // Calculate pagination
            const total = documents.length;
            const startIndex = (page - 1) * limit;
            const endIndex = page * limit;
            const paginatedDocuments = documents.slice(startIndex, endIndex);

            res.json({
                success: true,
                message: "Documents retrieved successfully",
                documents: paginatedDocuments,
                pagination: {
                    total,
                    page: parseInt(page),
                    limit: parseInt(limit),
                    totalPages: Math.ceil(total / limit),
                    hasNextPage: endIndex < total,
                    hasPrevPage: startIndex > 0
                }
            });
        } catch (error) {
            console.error("Error searching documents:", error);
            res.status(500).json({
                success: false,
                message: "Error searching documents",
                error: error.message
            });
        }
    }

    // Get document statistics
    static async getDocumentStatistics(req, res) {
        try {
            const statistics = await DocumentModel.getStatistics();
            
            res.json({
                success: true,
                message: "Statistics retrieved successfully",
                statistics: statistics
            });
        } catch (error) {
            console.error("Error getting statistics:", error);
            res.status(500).json({
                success: false,
                message: "Error retrieving statistics",
                error: error.message
            });
        }
    }

    // Toggle document status
    static async toggleDocumentStatus(req, res) {
        try {
            const { id } = req.params;
            const { is_active } = req.body;

            if (is_active === undefined) {
                return res.status(400).json({
                    success: false,
                    message: "is_active field is required"
                });
            }

            // Check if document exists
            const existingDocument = await DocumentModel.findById(id);
            if (!existingDocument) {
                return res.status(404).json({
                    success: false,
                    message: "Document not found"
                });
            }

            // Update status
            const updatedDocument = await DocumentModel.update(id, { is_active });

            res.json({
                success: true,
                message: `Document ${is_active ? 'activated' : 'deactivated'} successfully`,
                document: updatedDocument
            });
        } catch (error) {
            console.error("Error toggling document status:", error);
            res.status(500).json({
                success: false,
                message: "Error updating document status",
                error: error.message
            });
        }
    }

    // Get recent documents
    static async getRecentDocuments(req, res) {
        try {
            const { limit = 10 } = req.query;
            const documents = await DocumentModel.getRecent(parseInt(limit));
            
            res.json({
                success: true,
                message: "Recent documents retrieved successfully",
                documents: documents,
                count: documents.length
            });
        } catch (error) {
            console.error("Error getting recent documents:", error);
            res.status(500).json({
                success: false,
                message: "Error retrieving recent documents",
                error: error.message
            });
        }
    }

    // Check document access (helper method)
    static async checkDocumentAccess(user, document) {
        // If document is public, anyone can access
        if (document.access_level === 'public') {
            return true;
        }

        // If no user, deny access for restricted/private documents
        if (!user) {
            return false;
        }

        // If document is private, only owner and ADMIN can access
        if (document.access_level === 'private') {
            if (user.id === document.uploaded_by || user.role_code === 'ADMIN') {
                return true;
            }
            return false;
        }

        // If document is restricted, check allowed roles
        if (document.access_level === 'restricted') {
            if (!document.allowed_roles || document.allowed_roles.length === 0) {
                return false;
            }
            
            // Parse allowed_roles if it's a string
            const allowedRoles = Array.isArray(document.allowed_roles)
                ? document.allowed_roles
                : JSON.parse(document.allowed_roles || '[]');
            
            // Check if user role is in allowed roles
            if (allowedRoles.includes(user.role_code)) {
                return true;
            }

            // Check allowed users
            if (document.allowed_users) {
                const allowedUsers = Array.isArray(document.allowed_users)
                    ? document.allowed_users
                    : JSON.parse(document.allowed_users || '[]');
                
                if (allowedUsers.includes(user.id)) {
                    return true;
                }
            }

            return false;
        }

        return false;
    }

    // Get documents by folder
    static async getDocumentsByFolder(req, res) {
        try {
            const { folderId } = req.params;
            
            if (!folderId) {
                return res.status(400).json({
                    success: false,
                    message: "Folder ID is required"
                });
            }

            const documents = await DocumentModel.findByFolderId(folderId);
            
            res.json({
                success: true,
                message: "Documents retrieved successfully",
                documents: documents,
                count: documents.length
            });
        } catch (error) {
            console.error("Error getting documents by folder:", error);
            res.status(500).json({
                success: false,
                message: "Error retrieving documents",
                error: error.message
            });
        }
    }

    // Get documents by user
    static async getDocumentsByUser(req, res) {
        try {
            const { userId } = req.params;
            
            if (!userId) {
                return res.status(400).json({
                    success: false,
                    message: "User ID is required"
                });
            }

            const documents = await DocumentModel.findByUploadedBy(userId);
            
            res.json({
                success: true,
                message: "Documents retrieved successfully",
                documents: documents,
                count: documents.length
            });
        } catch (error) {
            console.error("Error getting documents by user:", error);
            res.status(500).json({
                success: false,
                message: "Error retrieving documents",
                error: error.message
            });
        }
    }
}

module.exports = DocumentController;
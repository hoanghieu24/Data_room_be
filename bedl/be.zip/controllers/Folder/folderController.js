const folderServices = require('../../services/Folder/folderServices');
class FolderController {
    static async getAllFolders(req, res) {
        try {
            const folders = await folderServices.getAllFolders();
            res.status(200).json({
    success: true,
    total: folders?.length || 0,
    data: folders || []
});


        } catch (error) {
            res.status(500).json({ error: 'Internal Server Error' });
        }
    }
}
module.exports = FolderController;
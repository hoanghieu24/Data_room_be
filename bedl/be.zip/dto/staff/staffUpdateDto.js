class StaffUpdateDTO {
  constructor(data) {
    this.id = data.id;
    this.employeeCode = data.employeeCode;        
    this.fullName = data.fullName;

    this.positionId = data.positionId;
    this.jobTitle = data.jobTitle || null;
    this.departmentId = data.departmentId || null;
    this.managerId = data.managerId || null;

    this.contractType = data.contractType || null;
    this.contractNumber = data.contractNumber || null;
    this.contractStartDate = data.contractStartDate || null;
    this.contractEndDate = data.contractEndDate || null;

    this.salaryGrade = data.salaryGrade || null;
    this.basicSalary = data.basicSalary || 0;
    this.allowance = data.allowance || {};           
    this.bankAccount = data.bankAccount || null;
    this.bankName = data.bankName || null;

    this.workLocation = data.workLocation || null;
    this.workingHours = data.workingHours || { start: "08:00", end: "17:00" };

    this.probationPeriod = data.probationPeriod || null;
    this.probationEndDate = data.probationEndDate || null;
    this.officialStartDate = data.officialStartDate || null;

    this.employmentStatus = data.employmentStatus || "WORKING";

    this.emergencyContactName = data.emergencyContactName || null;
    this.emergencyContactPhone = data.emergencyContactPhone || null;
    this.emergencyContactRelation = data.emergencyContactRelation || null;

    this.hrNotes = data.hrNotes || null;
    this.performanceNotes = null;

    this.createdBy = data.createdBy || null;
  }
}

module.exports = StaffUpdateDTO;

const DocumentModel = require("../models/DocumentModel");
const { generateDocumentCode, validateFileType, getFileExtension } = require("../utils/documentUtils");
const fs = require("fs").promises;
const path = require("path");

class DocumentService {
    // Get all documents
    static async getAllDocuments() {
        try {
            const documents = await DocumentModel.findAll();
            return {
                success: true,
                data: documents,
                message: "Documents retrieved successfully"
            };
        } catch (error) {
            console.error("Service error in getAllDocuments:", error);
            throw new Error("Failed to retrieve documents");
        }
    }

    // Get document by ID
    static async getDocumentById(id) {
        try {
            const document = await DocumentModel.findById(id);
            if (!document) {
                return {
                    success: false,
                    message: "Document not found"
                };
            }
            return {
                success: true,
                data: document,
                message: "Document retrieved successfully"
            };
        } catch (error) {
            console.error("Service error in getDocumentById:", error);
            throw new Error("Failed to retrieve document");
        }
    }

    // Create new document
    static async createDocument(documentData, file) {
        try {
            // Validate required fields
            if (!documentData.name || !file) {
                return {
                    success: false,
                    message: "Name and file are required"
                };
            }

            // Validate file type
            if (!validateFileType(file.mimetype)) {
                return {
                    success: false,
                    message: "Invalid file type"
                };
            }

            // Generate document code
            const documentCode = await generateDocumentCode();

            // Prepare document data
            const newDocumentData = {
                document_code: documentCode,
                name: documentData.name,
                description: documentData.description,
                folder_id: documentData.folder_id,
                file_name: file.originalname,
                file_path: file.path,
                file_size: file.size,
                file_type: getFileExtension(file.mimetype),
                mime_type: file.mimetype,
                access_level: documentData.access_level || 'restricted',
                allowed_roles: documentData.allowed_roles || ['ADMIN'],
                allowed_users: documentData.allowed_users,
                metadata: documentData.metadata,
                tags: documentData.tags,
                is_encrypted: documentData.is_encrypted || false,
                expiry_date: documentData.expiry_date,
                uploaded_by: documentData.uploaded_by || 1
            };

            // Create document
            const document = await DocumentModel.create(newDocumentData);

            return {
                success: true,
                data: document,
                message: "Document created successfully"
            };
        } catch (error) {
            console.error("Service error in createDocument:", error);
            // Clean up uploaded file if error occurs
            if (file && file.path) {
                await fs.unlink(file.path).catch(console.error);
            }
            throw new Error("Failed to create document");
        }
    }

    // Update document
    static async updateDocument(id, updateData) {
        try {
            // Check if document exists
            const existingDocument = await DocumentModel.findById(id);
            if (!existingDocument) {
                return {
                    success: false,
                    message: "Document not found"
                };
            }

            // Update document
            const updatedDocument = await DocumentModel.update(id, updateData);

            return {
                success: true,
                data: updatedDocument,
                message: "Document updated successfully"
            };
        } catch (error) {
            console.error("Service error in updateDocument:", error);
            throw new Error("Failed to update document");
        }
    }

    // Delete document
    static async deleteDocument(id) {
        try {
            // Check if document exists
            const existingDocument = await DocumentModel.findById(id);
            if (!existingDocument) {
                return {
                    success: false,
                    message: "Document not found"
                };
            }

            // Delete document (soft delete)
            const deleted = await DocumentModel.delete(id);

            if (deleted) {
                return {
                    success: true,
                    message: "Document deleted successfully"
                };
            } else {
                return {
                    success: false,
                    message: "Failed to delete document"
                };
            }
        } catch (error) {
            console.error("Service error in deleteDocument:", error);
            throw new Error("Failed to delete document");
        }
    }

    // Download document
    static async downloadDocument(id, userId) {
        try {
            // Get document
            const document = await DocumentModel.findById(id);
            if (!document) {
                return {
                    success: false,
                    message: "Document not found"
                };
            }

            // Check if file exists
            try {
                await fs.access(document.file_path);
            } catch (error) {
                return {
                    success: false,
                    message: "File not found on server"
                };
            }

            // Increment download count
            await DocumentModel.incrementDownloadCount(id);

            return {
                success: true,
                data: {
                    filePath: document.file_path,
                    fileName: document.file_name,
                    mimeType: document.mime_type,
                    fileSize: document.file_size
                },
                message: "Document ready for download"
            };
        } catch (error) {
            console.error("Service error in downloadDocument:", error);
            throw new Error("Failed to prepare document for download");
        }
    }

    // Search documents
    static async searchDocuments(searchParams) {
        try {
            const documents = await DocumentModel.search(searchParams);
            
            return {
                success: true,
                data: documents,
                message: "Documents retrieved successfully"
            };
        } catch (error) {
            console.error("Service error in searchDocuments:", error);
            throw new Error("Failed to search documents");
        }
    }

    // Get document statistics
    static async getDocumentStatistics() {
        try {
            const statistics = await DocumentModel.getStatistics();
            
            return {
                success: true,
                data: statistics,
                message: "Statistics retrieved successfully"
            };
        } catch (error) {
            console.error("Service error in getDocumentStatistics:", error);
            throw new Error("Failed to retrieve statistics");
        }
    }

    // Toggle document status
    static async toggleDocumentStatus(id, isActive) {
        try {
            // Check if document exists
            const existingDocument = await DocumentModel.findById(id);
            if (!existingDocument) {
                return {
                    success: false,
                    message: "Document not found"
                };
            }

            // Update status
            const updatedDocument = await DocumentModel.update(id, { is_active: isActive });

            return {
                success: true,
                data: updatedDocument,
                message: `Document ${isActive ? 'activated' : 'deactivated'} successfully`
            };
        } catch (error) {
            console.error("Service error in toggleDocumentStatus:", error);
            throw new Error("Failed to update document status");
        }
    }

    // Get recent documents
    static async getRecentDocuments(limit = 10) {
        try {
            const documents = await DocumentModel.getRecent(limit);
            
            return {
                success: true,
                data: documents,
                message: "Recent documents retrieved successfully"
            };
        } catch (error) {
            console.error("Service error in getRecentDocuments:", error);
            throw new Error("Failed to retrieve recent documents");
        }
    }

    // Get documents by folder
    static async getDocumentsByFolder(folderId) {
        try {
            const documents = await DocumentModel.findByFolderId(folderId);
            
            return {
                success: true,
                data: documents,
                message: "Documents retrieved successfully"
            };
        } catch (error) {
            console.error("Service error in getDocumentsByFolder:", error);
            throw new Error("Failed to retrieve documents by folder");
        }
    }

    // Check document access
    static async checkDocumentAccess(documentId, user) {
        try {
            const document = await DocumentModel.findById(documentId);
            if (!document) {
                return false;
            }

            // If document is public
            if (document.access_level === 'public') {
                return true;
            }

            // If no user
            if (!user) {
                return false;
            }

            // If document is private
            if (document.access_level === 'private') {
                return user.id === document.uploaded_by || user.role_code === 'ADMIN';
            }

            // If document is restricted
            if (document.access_level === 'restricted') {
                if (!document.allowed_roles || document.allowed_roles.length === 0) {
                    return false;
                }

                const allowedRoles = Array.isArray(document.allowed_roles)
                    ? document.allowed_roles
                    : JSON.parse(document.allowed_roles || '[]');

                if (allowedRoles.includes(user.role_code)) {
                    return true;
                }

                // Check allowed users
                if (document.allowed_users) {
                    const allowedUsers = Array.isArray(document.allowed_users)
                        ? document.allowed_users
                        : JSON.parse(document.allowed_users || '[]');
                    
                    if (allowedUsers.includes(user.id)) {
                        return true;
                    }
                }

                return false;
            }

            return false;
        } catch (error) {
            console.error("Service error in checkDocumentAccess:", error);
            return false;
        }
    }
}

module.exports = DocumentService;
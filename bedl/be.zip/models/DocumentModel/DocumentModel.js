const db = require("../../db");

class DocumentModel {
    // Get all documents
    static async findAll() {
        const [rows] = await db.query(
            `SELECT d.*, 
                    u.username as uploaded_by_name,
                    f.name as folder_name
             FROM documents d
             LEFT JOIN users u ON d.uploaded_by = u.id
             LEFT JOIN folders f ON d.folder_id = f.id
             ORDER BY d.created_at DESC`
        );
        return rows;
    }

    // Get document by ID
    static async findById(id) {
        const [rows] = await db.query(
            `SELECT d.*, 
                    u.username as uploaded_by_name,
                    f.name as folder_name
             FROM documents d
             LEFT JOIN users u ON d.uploaded_by = u.id
             LEFT JOIN folders f ON d.folder_id = f.id
             WHERE d.id = ? `,
            [id]
        );
        return rows[0] || null;
    }

    // Get document by document_code
    static async findByDocumentCode(document_code) {
        const [rows] = await db.query(
            "SELECT * FROM documents WHERE document_code = ? AND is_active = 1",
            [document_code]
        );
        return rows[0] || null;
    }

    // Create new document
    static async create(documentData) {
        const {
            document_code, folder_id, name, description,
            file_name, file_path, file_size, file_type,
            mime_type, version, access_level, allowed_roles,
            allowed_users, metadata, tags, is_encrypted,
            expiry_date, uploaded_by
        } = documentData;

        const [result] = await db.query(
            `INSERT INTO documents (
                document_code, folder_id, name, description,
                file_name, file_path, file_size, file_type,
                mime_type, version, access_level, allowed_roles,
                allowed_users, metadata, tags, is_encrypted,
                expiry_date, uploaded_by
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
                document_code, folder_id, name, description,
                file_name, file_path, file_size, file_type,
                mime_type, version || 1, access_level || 'restricted',
                allowed_roles ? JSON.stringify(allowed_roles) : null,
                allowed_users ? JSON.stringify(allowed_users) : null,
                metadata ? JSON.stringify(metadata) : null,
                tags ? JSON.stringify(tags) : null,
                is_encrypted || 0,
                expiry_date, uploaded_by
            ]
        );

        return this.findById(result.insertId);
    }

    // Update document
    static async update(id, documentData) {
        const {
            name, description, folder_id, access_level,
            allowed_roles, allowed_users, metadata, tags,
            is_encrypted, is_active, version
        } = documentData;

        const updateFields = [];
        const values = [];

        if (name !== undefined) {
            updateFields.push("name = ?");
            values.push(name);
        }
        if (description !== undefined) {
            updateFields.push("description = ?");
            values.push(description);
        }
        if (folder_id !== undefined) {
            updateFields.push("folder_id = ?");
            values.push(folder_id);
        }
        if (access_level !== undefined) {
            updateFields.push("access_level = ?");
            values.push(access_level);
        }
        if (allowed_roles !== undefined) {
            updateFields.push("allowed_roles = ?");
            values.push(allowed_roles ? JSON.stringify(allowed_roles) : null);
        }
        if (allowed_users !== undefined) {
            updateFields.push("allowed_users = ?");
            values.push(allowed_users ? JSON.stringify(allowed_users) : null);
        }
        if (metadata !== undefined) {
            updateFields.push("metadata = ?");
            values.push(metadata ? JSON.stringify(metadata) : null);
        }
        if (tags !== undefined) {
            updateFields.push("tags = ?");
            values.push(tags ? JSON.stringify(tags) : null);
        }
        if (is_encrypted !== undefined) {
            updateFields.push("is_encrypted = ?");
            values.push(is_encrypted);
        }
        if (is_active !== undefined) {
            updateFields.push("is_active = ?");
            values.push(is_active);
        }
        if (version !== undefined) {
            updateFields.push("version = ?");
            values.push(version);
        }

        updateFields.push("updated_at = CURRENT_TIMESTAMP");

        values.push(id);

        await db.query(
            `UPDATE documents SET ${updateFields.join(", ")} WHERE id = ?`,
            values
        );

        return this.findById(id);
    }

    // Delete document (soft delete)
    static async delete(id) {
        const [result] = await db.query(
                "DELETE FROM documents WHERE id = ?",
            [id]
        );
        return result.affectedRows > 0;
    }

    // Hard delete document
    static async hardDelete(id) {
        const [result] = await db.query(
            "DELETE FROM documents WHERE id = ?",
            [id]
        );
        return result.affectedRows > 0;
    }

    // Increment download count
    static async incrementDownloadCount(id) {
        const [result] = await db.query(
            "UPDATE documents SET download_count = download_count + 1 WHERE id = ?",
            [id]
        );
        return result.affectedRows > 0;
    }

    // Increment view count
    static async incrementViewCount(id) {
        const [result] = await db.query(
            "UPDATE documents SET view_count = view_count + 1 WHERE id = ?",
            [id]
        );
        return result.affectedRows > 0;
    }

    // Search documents
    static async search(searchParams) {
        const { searchTerm, fileType, accessLevel, folderId, isActive } = searchParams;
        
        let query = `
            SELECT d.*, 
                   u.username as uploaded_by_name,
                   f.name as folder_name
            FROM documents d
            LEFT JOIN users u ON d.uploaded_by = u.id
            LEFT JOIN folders f ON d.folder_id = f.id
            WHERE 1=1
        `;
        
        const values = [];
        
        if (searchTerm) {
            query += ` AND (d.name LIKE ? OR d.document_code LIKE ? OR d.description LIKE ?)`;
            const searchValue = `%${searchTerm}%`;
            values.push(searchValue, searchValue, searchValue);
        }
        
        if (fileType) {
            query += ` AND d.file_type = ?`;
            values.push(fileType);
        }
        
        if (accessLevel) {
            query += ` AND d.access_level = ?`;
            values.push(accessLevel);
        }
        
        if (folderId) {
            query += ` AND d.folder_id = ?`;
            values.push(folderId);
        }
        
        if (isActive !== undefined) {
            query += ` AND d.is_active = ?`;
            values.push(isActive);
        } else {
            query += ` AND d.is_active = 1`;
        }
        
        query += ` ORDER BY d.created_at DESC`;
        
        const [rows] = await db.query(query, values);
        return rows;
    }

    // Get documents by folder ID
    static async findByFolderId(folderId) {
        const [rows] = await db.query(
            `SELECT d.*, 
                    u.username as uploaded_by_name,
                    f.name as folder_name
             FROM documents d
             LEFT JOIN users u ON d.uploaded_by = u.id
             LEFT JOIN folders f ON d.folder_id = f.id
             WHERE d.folder_id = ? AND d.is_active = 1
             ORDER BY d.created_at DESC`,
            [folderId]
        );
        return rows;
    }

    // Get documents by uploaded user
    static async findByUploadedBy(userId) {
        const [rows] = await db.query(
            `SELECT d.*, 
                    u.username as uploaded_by_name,
                    f.name as folder_name
             FROM documents d
             LEFT JOIN users u ON d.uploaded_by = u.id
             LEFT JOIN folders f ON d.folder_id = f.id
             WHERE d.uploaded_by = ? AND d.is_active = 1
             ORDER BY d.created_at DESC`,
            [userId]
        );
        return rows;
    }

    // Get document statistics
    static async getStatistics() {
        const [stats] = await db.query(`
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN file_type = 'pdf' THEN 1 ELSE 0 END) as pdf_count,
                SUM(CASE WHEN file_type IN ('xlsx', 'xls') THEN 1 ELSE 0 END) as excel_count,
                SUM(CASE WHEN file_type IN ('docx', 'doc') THEN 1 ELSE 0 END) as word_count,
                SUM(file_size) as total_size,
                SUM(download_count) as total_downloads,
                SUM(view_count) as total_views,
                SUM(CASE WHEN is_encrypted = 1 THEN 1 ELSE 0 END) as encrypted_count,
                COUNT(CASE WHEN expiry_date < NOW() AND expiry_date IS NOT NULL THEN 1 END) as expired_count,
                SUM(CASE WHEN access_level = 'public' THEN 1 ELSE 0 END) as public_count,
                SUM(CASE WHEN access_level = 'restricted' THEN 1 ELSE 0 END) as restricted_count,
                SUM(CASE WHEN access_level = 'private' THEN 1 ELSE 0 END) as private_count
            FROM documents 
            WHERE is_active = 1
        `);
        
        return stats[0];
    }

    // Check if document exists
    static async exists(id) {
        const [rows] = await db.query(
            "SELECT 1 FROM documents WHERE id = ? AND is_active = 1",
            [id]
        );
        return rows.length > 0;
    }

    // Get recent documents
    static async getRecent(limit = 10) {
        const [rows] = await db.query(
            `SELECT d.*, 
                    u.username as uploaded_by_name,
                    f.name as folder_name
             FROM documents d
             LEFT JOIN users u ON d.uploaded_by = u.id
             LEFT JOIN folders f ON d.folder_id = f.id
             WHERE d.is_active = 1
             ORDER BY d.created_at DESC
             LIMIT ?`,
            [limit]
        );
        return rows;
    }

    // Get documents by access level and role
    static async findByAccess(accessLevel, role) {
        const [rows] = await db.query(
            `SELECT d.*, 
                    u.username as uploaded_by_name,
                    f.name as folder_name
             FROM documents d
             LEFT JOIN users u ON d.uploaded_by = u.id
             LEFT JOIN folders f ON d.folder_id = f.id
             WHERE d.access_level = ? 
               AND (d.allowed_roles IS NULL OR JSON_CONTAINS(d.allowed_roles, ?))
               AND d.is_active = 1
             ORDER BY d.created_at DESC`,
            [accessLevel, JSON.stringify(role)]
        );
        return rows;
    }
}

module.exports = DocumentModel;
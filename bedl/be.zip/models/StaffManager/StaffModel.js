const db = require("../../db");

/* ================== AUTO GENERATE EMPLOYEE CODE ================== */
const generateEmployeeCode = async () => {
    const [rows] = await db.query(
        "SELECT employee_code FROM employee_management ORDER BY id DESC LIMIT 1"
    );

    if (rows.length === 0 || !rows[0].employee_code) {
        return "HRM003";
    }

    const lastCode = rows[0].employee_code; // HRM003
    const number = parseInt(lastCode.replace("HRM", ""), 10) + 1;
    return `HRM${number.toString().padStart(3, "0")}`;
};

class StaffModel {
    /* ================== GET ALL ================== */
    static async getAllStaff() {
        const [rows] = await db.query("SELECT * FROM employee_management");
        return rows;
    }

    /* ================== CREATE ================== */
    static async createStaff(dto) {
        // ✅ AUTO GEN nếu FE không gửi
        const employeeCode = dto.employeeCode || await generateEmployeeCode();

        const sql = `
            INSERT INTO employee_management (
              employee_id, employee_code, full_name,
              position_id, job_title, department_id, manager_id,
              contract_type, contract_number, contract_start_date, contract_end_date,
              salary_grade, basic_salary, allowance, bank_account, bank_name,
              work_location, working_hours,
              probation_period, probation_end_date, official_start_date,
              employment_status,
              emergency_contact_name, emergency_contact_phone, emergency_contact_relation,
              hr_notes
            )
            VALUES (
              ?,?,?,?,?,?,?,
              ?,?,?,?,
              ?,?,?,?,?,
              ?,?,
              ?,?,?,
              ?,
              ?,?,?,
              ?
            )
        `;

        const params = [
            dto.employeeId || null,
            employeeCode,
            dto.fullName,

            dto.positionId,
            dto.jobTitle || null,
            dto.departmentId || null,
            dto.managerId || null,

            dto.contractType || null,
            dto.contractNumber || null,
            dto.contractStartDate || null,
            dto.contractEndDate || null,

            dto.salaryGrade || null,
            dto.basicSalary || null,
            JSON.stringify(dto.allowance || []),
            dto.bankAccount || null,
            dto.bankName || null,

            dto.workLocation || null,
            JSON.stringify(dto.workingHours || {}),

            dto.probationPeriod || null,
            dto.probationEndDate || null,
            dto.officialStartDate || null,

            dto.employmentStatus || 1,

            dto.emergencyContactName || null,
            dto.emergencyContactPhone || null,
            dto.emergencyContactRelation || null,

            dto.hrNotes || null
        ];

        const [result] = await db.query(sql, params);
        return {
            id: result.insertId,
            employee_code: employeeCode
        };
    }

    /* ================== UPDATE ================== */
    static async updateStaff(dto) {
        const [result] = await db.query(
            `
            UPDATE employee_management SET
                employee_code = ?, full_name = ?,
                position_id = ?, job_title = ?, department_id = ?, manager_id = ?,
                contract_type = ?, contract_number = ?, contract_start_date = ?, contract_end_date = ?,
                salary_grade = ?, basic_salary = ?, allowance = ?, bank_account = ?, bank_name = ?,
                work_location = ?, working_hours = ?,
                probation_period = ?, probation_end_date = ?, official_start_date = ?,
                employment_status = ?,
                emergency_contact_name = ?, emergency_contact_phone = ?, emergency_contact_relation = ?,
                hr_notes = ?
            WHERE id = ?
            `,
            [
                dto.employeeCode,
                dto.fullName,

                dto.positionId,
                dto.jobTitle,
                dto.departmentId,
                dto.managerId,

                dto.contractType,
                dto.contractNumber,
                dto.contractStartDate,
                dto.contractEndDate,

                dto.salaryGrade,
                dto.basicSalary,
                JSON.stringify(dto.allowance || []),
                dto.bankAccount,
                dto.bankName,

                dto.workLocation,
                JSON.stringify(dto.workingHours || {}),

                dto.probationPeriod,
                dto.probationEndDate,
                dto.officialStartDate,

                dto.employmentStatus,

                dto.emergencyContactName,
                dto.emergencyContactPhone,
                dto.emergencyContactRelation,

                dto.hrNotes,
                dto.id
            ]
        );

        return result.affectedRows;
    }

    /* ================== DELETE ================== */
    static async deleteStaff(id) {
        const [result] = await db.query(
            "DELETE FROM employee_management WHERE id = ?",
            [id]
        );
        return result.affectedRows;
    }

    static async deleteStaffs(ids) {
        const [result] = await db.query(
            "DELETE FROM employee_management WHERE id IN (?)",
            [ids]
        );
        return result.affectedRows;
    }
}

module.exports = StaffModel;
